# Handler code for annotation_lambda 
import os
import io
import json
import logging
from typing import Dict, Any, Optional, Tuple

import boto3
from botocore.exceptions import ClientError
import google.generativeai as genai
from google.generativeai import types # 添加导入
import mysql.connector
from mysql.connector import errorcode
import magic # 导入 magic 库

# --- Custom Exceptions --- (No longer web_app.utils)
from custom_exceptions import (
    COMP5349A2Error,
    S3InteractionError,
    DatabaseError,
    GeminiAPIError,
    InvalidInputError,
    ConfigurationError
)

# --- Logger Setup ---
logger = logging.getLogger()
log_level_str = os.environ.get('LOG_LEVEL', 'INFO').upper()
logger.setLevel(getattr(logging, log_level_str, logging.INFO))

# Environment variables for Lambda configuration (consider defaults or raise errors if not set)
DB_HOST_LAMBDA = os.environ.get('DB_HOST_LAMBDA')

def _get_db_connection_lambda(aws_request_id: str) -> mysql.connector.MySQLConnection:
    """
    Establishes a database connection using environment variables.
    
    Args:
        aws_request_id: The AWS request ID for logging correlation.
        
    Returns:
        mysql.connector.MySQLConnection: A database connection object.
        
    Raises:
        ConfigurationError: If required environment variables are missing.
        DatabaseError: If database connection fails.
    """
    # Get database configuration from environment variables
    db_host = os.environ.get('DB_HOST')
    db_user = os.environ.get('DB_USER')
    db_password = os.environ.get('DB_PASSWORD')
    db_name = os.environ.get('DB_NAME')
    db_port = os.environ.get('DB_PORT', '3306')

    # Validate required configuration
    if not all([db_host, db_user, db_password, db_name]):
        missing_vars = [var for var, val in {
            'DB_HOST': db_host,
            'DB_USER': db_user,
            'DB_PASSWORD': db_password,
            'DB_NAME': db_name
        }.items() if not val]
        error_msg = f"Missing required database configuration: {', '.join(missing_vars)}"
        logger.error(error_msg, extra={'request_id': aws_request_id})
        raise ConfigurationError(error_msg, error_code='DB_CONFIG_MISSING')

    try:
        # Attempt to establish database connection
        logger.info(f"Attempting to connect to database {db_host}/{db_name}",
                   extra={'request_id': aws_request_id})
        
        connection = mysql.connector.connect(
            host=db_host,
            user=db_user,
            password=db_password,
            database=db_name,
            port=int(db_port)
        )
        
        logger.info("Database connection established successfully",
                   extra={'request_id': aws_request_id})
        return connection
        
    except mysql.connector.Error as e:
        error_msg = f"Failed to connect to database: {str(e)}"
        logger.error(error_msg, extra={'request_id': aws_request_id})
        raise DatabaseError(error_msg, error_code='DB_CONNECTION_FAILED', original_exception=e)

def _update_caption_in_db(db_conn, s3_key_original: str, annotation_text: Optional[str], 
                         status: str, aws_request_id: str) -> bool:
    """
    Updates the annotation text and status for an image in the database.
    Uses 'annotation', 'annotation_status', and 's3_key_original' columns.
    
    Args:
        db_conn: Database connection object.
        s3_key_original: The S3 key of the original image (matches DB column name).
        annotation_text: The generated annotation text or error message.
        status: The status to set ('completed' or 'failed').
        aws_request_id: The AWS request ID for logging correlation.
        
    Returns:
        bool: True if the update was successful and affected at least one row.
        
    Raises:
        InvalidInputError: If status is not 'completed' or 'failed'.
        DatabaseError: If database operation fails.
    """
    # Validate status
    if status not in ['completed', 'failed']:
        error_msg = f"Invalid status '{status}'. Must be 'completed' or 'failed'."
        logger.error(error_msg, extra={'request_id': aws_request_id})
        raise InvalidInputError(error_msg, error_code='INVALID_STATUS')

    cursor = None # Ensure cursor is defined for the finally block
    try:
        cursor = db_conn.cursor()
        
        # SQL uses annotation, annotation_status, and s3_key_original
        sql = """
            UPDATE images 
            SET annotation = %s, annotation_status = %s 
            WHERE s3_key_original = %s
        """
        cursor.execute(sql, (annotation_text, status, s3_key_original))
        db_conn.commit()
        
        affected_rows = cursor.rowcount
        
        if affected_rows > 0:
            logger.info(f"Successfully updated annotation_status to '{status}' for {s3_key_original}",
                       extra={'request_id': aws_request_id})
            return True
        else:
            logger.warning(f"No record found in database for s3_key_original: {s3_key_original} during annotation status update.",
                          extra={'request_id': aws_request_id})
            return False
            
    except mysql.connector.Error as e:
        error_msg = f"Database error while updating annotation: {str(e)}"
        logger.error(error_msg, extra={'request_id': aws_request_id})
        raise DatabaseError(error_msg, error_code='DB_UPDATE_FAILED', original_exception=e)
    finally:
        if cursor:
            cursor.close()

def _download_image_from_s3(bucket_name: str, object_key: str, aws_request_id: str) -> bytes:
    """
    Downloads an image from S3.
    
    Args:
        bucket_name: The S3 bucket name.
        object_key: The S3 object key.
        aws_request_id: The AWS request ID for logging correlation.
        
    Returns:
        bytes: The image data.
        
    Raises:
        S3InteractionError: If S3 operation fails.
    """
    try:
        logger.info(f"Downloading image from s3://{bucket_name}/{object_key}",
                   extra={'request_id': aws_request_id})
        
        s3_client = boto3.client('s3')
        response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
        image_data = response['Body'].read()
        
        logger.info(f"Successfully downloaded image ({len(image_data)} bytes)",
                   extra={'request_id': aws_request_id})
        return image_data
        
    except ClientError as e:
        error_msg = f"Failed to download image from S3: {str(e)}"
        logger.error(error_msg, extra={'request_id': aws_request_id})
        raise S3InteractionError(error_msg, error_code='S3_DOWNLOAD_FAILED', original_exception=e)

def _call_gemini_api(image_bytes: bytes, aws_request_id: str = "N/A") -> str:
    # Get Gemini configuration from environment variables
    gemini_api_key = os.environ.get("GEMINI_API_KEY")
    model_name = os.environ.get('GEMINI_MODEL_NAME', 'gemini-pro-vision')
    prompt_text = os.environ.get('GEMINI_PROMPT', 'Describe this image in detail.')

    if not gemini_api_key:
        logger.error("GEMINI_API_KEY environment variable not set.", extra={'request_id': aws_request_id})
        # Consider raising a more specific ConfigurationError if defined and appropriate
        raise ValueError("GEMINI_API_KEY not configured")

    try:
        genai.configure(api_key=gemini_api_key)
        model = genai.GenerativeModel(model_name=model_name)

        # MIME type detection
        mime_type = 'image/jpeg' # Default fallback
        try:
            detected_mime_type = magic.from_buffer(image_bytes, mime=True)
            logger.info(f"Detected MIME type: {detected_mime_type}", extra={'request_id': aws_request_id})
            # Gemini 支持: PNG (image/png), JPEG (image/jpeg), WEBP (image/webp), HEIC (image/heic), HEIF (image/heif)
            supported_mime_types = ['image/png', 'image/jpeg', 'image/webp', 'image/heic', 'image/heif']
            if detected_mime_type in supported_mime_types:
                mime_type = detected_mime_type
            else:
                logger.warning(f"Unsupported MIME type detected by python-magic: {detected_mime_type}. Defaulting to {mime_type}.",
                               extra={'request_id': aws_request_id})
                # Optionally, you could raise an error here if strict type checking is needed:
                # raise GeminiAPIError(f"Unsupported MIME type: {detected_mime_type}", error_code='UNSUPPORTED_MIME_TYPE')
        except Exception as magic_e: #捕获 python-magic 可能的错误
            logger.error(f"Error detecting MIME type with python-magic: {str(magic_e)}. Defaulting to {mime_type}.",
                           extra={'request_id': aws_request_id})
            # mime_type remains the default 'image/jpeg'

        # Log the type of image_bytes and mime_type
        logger.debug(f"Type of image_bytes: {type(image_bytes)}, length: {len(image_bytes)}")
        logger.debug(f"MIME type for Gemini: {mime_type}")

        if not image_bytes:
            logger.error("Image bytes are empty. Cannot call Gemini API.", extra={'request_id': aws_request_id})
            raise ValueError("Image data is empty")

        image_part = types.Part.from_bytes(data=image_bytes, mime_type=mime_type)

        prompt_parts = [
            image_part,
            prompt_text # Use the variable defined above
        ]

        logger.info(f"Calling Gemini API ({model_name}) for image captioning with prompt: '{prompt_text}' and MIME type: {mime_type}",
                    extra={'request_id': aws_request_id})
        
        response = model.generate_content(prompt_parts)
        
        # Check for blocked content or other issues if the API supports it directly in response
        # For example, some APIs might have response.blocked or response.error
        # For google-generativeai, check response.prompt_feedback for block reasons
        if response.prompt_feedback and response.prompt_feedback.block_reason:
            block_reason = response.prompt_feedback.block_reason
            block_message = response.prompt_feedback.block_reason_message if hasattr(response.prompt_feedback, 'block_reason_message') else "No specific message."
            logger.error(f"Gemini API content generation blocked. Reason: {block_reason}, Message: {block_message}", extra={'request_id': aws_request_id})
            raise GeminiAPIError(f"Content generation blocked by API. Reason: {block_reason}. {block_message}", error_code='CONTENT_BLOCKED')

        if not response.candidates or not response.candidates[0].content or not response.candidates[0].content.parts:
            logger.error("Gemini API response is empty or not in the expected format.", extra={'request_id': aws_request_id})
            raise GeminiAPIError("Invalid or empty response from Gemini API", error_code='EMPTY_RESPONSE')

        caption = response.candidates[0].content.parts[0].text
        logger.info(f"Successfully received caption from Gemini API: '{caption}'", extra={'request_id': aws_request_id})
        return caption

    except COMP5349A2Error: # Catch our custom errors (includes GeminiAPIError, ConfigurationError etc.)
        raise # Re-raise them directly without modification or further wrapping
    except Exception as e:
        error_msg = f"Gemini API interaction failed: {str(e)}"
        logger.error(error_msg, exc_info=True, extra={'request_id': aws_request_id})
        raise GeminiAPIError(error_msg, error_code='GEMINI_API_ERROR', original_exception=e)

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    AWS Lambda handler for image annotation.
    
    Args:
        event: The S3 event that triggered the Lambda.
        context: The Lambda context object.
        
    Returns:
        Dict[str, Any]: A response indicating the processing status.
        
    Raises:
        Various exceptions that will trigger Lambda retries and eventually DLQ.
    """
    aws_request_id = context.aws_request_id
    logger.info("Lambda invocation started", extra={'request_id': aws_request_id})
    
    # Extract S3 event details
    try:
        bucket_name = event['Records'][0]['s3']['bucket']['name']
        object_key = event['Records'][0]['s3']['object']['key']
    except (KeyError, IndexError) as e:
        error_msg = f"Invalid S3 event structure: {str(e)}"
        logger.error(error_msg, extra={'request_id': aws_request_id})
        raise InvalidInputError(error_msg, error_code='INVALID_S3_EVENT')
    
    # Skip thumbnail objects
    if object_key.startswith('thumbnails/'):
        logger.info(f"Skipping thumbnail object: {object_key}",
                   extra={'request_id': aws_request_id})
        return {
            'status': 'skipped',
            's3_key': object_key,
            'reason': 'thumbnail_object'
        }
    
    # Initialize variables for processing
    db_conn = None
    status_to_set = 'failed'
    error_message_for_db = "Unknown processing error"
    caption_to_store = None
    return_payload = None
    exception_caught_during_processing = None
    
    # Main processing try-except block
    try:
        # Download image from S3
        image_bytes = _download_image_from_s3(bucket_name, object_key, aws_request_id)
        
        # Generate caption using Gemini
        caption_text_result = _call_gemini_api(image_bytes, aws_request_id)
        
        if caption_text_result:
            status_to_set = 'completed'
            caption_to_store = caption_text_result
            return_payload = {
                'status': 'success',
                's3_key': object_key,
                'caption_length': len(caption_text_result)
            }
        else:
            status_to_set = 'failed'
            caption_to_store = "Caption generation failed or content was blocked."
            return_payload = {
                'status': 'error',
                's3_key': object_key,
                'error_type': 'NoCaptionGenerated',
                'message': caption_to_store
            }
            
    except S3InteractionError as e:
        logger.error(f"S3 error: {e.message}", extra={'request_id': aws_request_id})
        status_to_set = 'failed'
        caption_to_store = f"S3 Download Error: {e.message}"
        return_payload = {
            'status': 'error',
            's3_key': object_key,
            'error_type': 'S3Error',
            'message': e.message
        }
        exception_caught_during_processing = e
        
    except GeminiAPIError as e:
        logger.error(f"Gemini API error: {e.message}", extra={'request_id': aws_request_id})
        status_to_set = 'failed'
        caption_to_store = f"Gemini API Error: {e.message}"
        return_payload = {
            'status': 'error',
            's3_key': object_key,
            'error_type': 'GeminiAPIError',
            'message': e.message
        }
        exception_caught_during_processing = e
        
    except ConfigurationError as e:
        logger.error(f"Configuration error: {e.message}", extra={'request_id': aws_request_id})
        status_to_set = 'failed'
        caption_to_store = f"Configuration Error: {e.message}"
        return_payload = {
            'status': 'error',
            's3_key': object_key,
            'error_type': 'ConfigurationError',
            'message': e.message
        }
        exception_caught_during_processing = e
        
    except Exception as e:
        logger.critical(f"Unexpected error: {str(e)}", exc_info=True,
                       extra={'request_id': aws_request_id})
        status_to_set = 'failed'
        caption_to_store = f"Unexpected processing error: {str(e)}"
        return_payload = {
            'status': 'error',
            's3_key': object_key,
            'error_type': 'UnexpectedError',
            'message': caption_to_store
        }
        exception_caught_during_processing = COMP5349A2Error(
            "Unexpected error during image processing",
            error_code='UNEXPECTED_ERROR',
            original_exception=e
        )
    
    # Database update try-except block
    try:
        db_conn = _get_db_connection_lambda(aws_request_id)
        update_success = _update_caption_in_db(
            db_conn, object_key, caption_to_store, status_to_set, aws_request_id
        )
        
        if not update_success:
            logger.warning(f"Database update did not affect any rows for {object_key}",
                          extra={'request_id': aws_request_id})
            
    except DatabaseError as db_e:
        logger.error(f"Database error during status update: {db_e.message}",
                    extra={'request_id': aws_request_id})
        # If a processing error already occurred, log that we couldn't update its status.
        # Otherwise, this db_e is the primary error to be raised.
        if not exception_caught_during_processing:
            exception_caught_during_processing = db_e
        else:
            logger.error("Original processing error's status could not be updated in the database due to a subsequent DatabaseError.", extra={'request_id': aws_request_id})
            
    except Exception as db_unhandled_e: # Catch any other unhandled DB-related exceptions
        logger.critical(f"Unhandled error during database operations: {str(db_unhandled_e)}",
                       exc_info=True, extra={'request_id': aws_request_id})
        if not exception_caught_during_processing:
            exception_caught_during_processing = COMP5349A2Error(
                f"Unhandled error during database operations: {str(db_unhandled_e)}",
                error_code='DB_UNHANDLED_ERROR',
                original_exception=db_unhandled_e
            )
        else:
            logger.error("Original processing error's status could not be updated in the database due to an unhandled exception during DB ops.", extra={'request_id': aws_request_id})
        
    finally:
        if db_conn:
            try:
                db_conn.close()
                logger.info("Database connection closed",
                           extra={'request_id': aws_request_id})
            except Exception as e:
                logger.error(f"Error closing database connection: {str(e)}",
                           extra={'request_id': aws_request_id})
    
    # Return or re-raise
    if exception_caught_during_processing:
        raise exception_caught_during_processing
        
    logger.info("Lambda invocation completed successfully",
                extra={'request_id': aws_request_id})
    return return_payload 